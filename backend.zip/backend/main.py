import os
import uuid
import hashlib
from datetime import datetime
from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import pymysql
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(title="API de Alertas de Salud - Telemetría")

# Permitir solicitudes CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def get_db_connection():
    try:
        connection = pymysql.connect(
            host=os.getenv("DB_HOST", "localhost"),
            user=os.getenv("DB_USER", "root"),
            password=os.getenv("DB_PASSWORD", ""),
            database=os.getenv("DB_NAME", "cft2026_appmoviles"),
            port=int(os.getenv("DB_PORT", 3307)),
            cursorclass=pymysql.cursors.DictCursor
        )
        return connection
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error conectando a la base de datos: {str(e)}"
        )

# --- MODELOS DE DATOS (PYDANTIC) ---

class UserRegisterRequest(BaseModel):
    name: str
    rut: str
    emergency_phone: str
    condition_type: str = "Ritmo Normal (60 - 100 BPM)"

class UserResponse(BaseModel):
    user_id: uuid.UUID
    name: str
    rut_hashed: str
    emergency_phone: str
    condition_type: str

class VitalSigns(BaseModel):
    user_id: uuid.UUID
    heart_rate: int = Field(..., ge=30, le=220)
    systolic_pressure: int
    diastolic_pressure: int

def hash_rut(rut: str) -> str:
    clean_rut = rut.replace(".", "").replace("-", "").upper()
    return hashlib.sha256(clean_rut.encode()).hexdigest()

# --- ENDPOINTS ---

@app.get("/")
def home():
    return {"status": "ok", "message": "Servidor backend activo"}

# 1. ENDPOINT REGISTRO DE USUARIO
@app.post("/users/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def register_user(user: UserRegisterRequest):
    user_id = str(uuid.uuid4())
    rut_protected = hash_rut(user.rut)

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            # SQL mapeado exactamente a los nombres de columna de tu MySQL Workbench
            sql = """
                INSERT INTO usuarios (user_id, nombre, rut_hashed, telefono_emergencia, condition_type)
                VALUES (%s, %s, %s, %s, %s)
            """
            cursor.execute(sql, (
                user_id,
                user.name,
                rut_protected,
                user.emergency_phone,
                user.condition_type
            ))
            conn.commit()

        return {
            "user_id": user_id,
            "name": user.name,
            "rut_hashed": rut_protected,
            "emergency_phone": user.emergency_phone,
            "condition_type": user.condition_type
        }
    except Exception as e:
        error_msg = str(e)
        print("======== ERROR MYSQL ========")
        print(error_msg)
        print("=============================")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"BD Error: {error_msg}"
        )
    finally:
        conn.close()

# 2. ENDPOINT RECEPCIÓN DE TELEMETRÍA Y ALERTAS SOS
@app.post("/telemetry/send")
def receive_telemetry(data: VitalSigns):
    conn = get_db_connection()
    user_str_id = str(data.user_id)
    alert_triggered = False
    alert_message = "Signos vitales dentro del rango normal."

    try:
        with conn.cursor() as cursor:
            # Obtener datos del usuario incluyendo su condición médica base
            # Cambiar emergency_phone por telefono_emergencia en la lectura:
            cursor.execute("SELECT telefono_emergencia AS emergency_phone, condition_type FROM usuarios WHERE user_id = %s", (user_str_id,))
            user = cursor.fetchone()

            if not user:
                raise HTTPException(status_code=404, detail="Usuario no encontrado")

            emergency_phone = user.get("emergency_phone", "Sin contacto")
            condition = user.get("condition_type", "Ritmo Normal")

            # Guardar la lectura de telemetría en MySQL
            sql_telemetry = """
                INSERT INTO lecturas_ritmo (user_id, heart_rate, systolic_pressure, diastolic_pressure)
                VALUES (%s, %s, %s, %s)
            """
            cursor.execute(sql_telemetry, (user_str_id, data.heart_rate, data.systolic_pressure, data.diastolic_pressure))

            # Evaluación personalizada según la condición médica elegida en el login
            if "Bradicardia" in condition:
                if data.heart_rate < 40 or data.heart_rate > 120:
                    alert_triggered = True
                    alert_message = f"ALERTA SOS: Ritmo crítico detectado ({data.heart_rate} BPM) para paciente bradicárdico."
            elif "Taquicardia" in condition:
                if data.heart_rate > 150:
                    alert_triggered = True
                    alert_message = f"ALERTA SOS: Ritmo muy elevado ({data.heart_rate} BPM) para paciente taquicárdico."
            else:
                if data.heart_rate < 50 or data.heart_rate > 130:
                    alert_triggered = True
                    alert_message = f"ALERTA SOS: Ritmo fuera de rango normal ({data.heart_rate} BPM)."

            # Si hay emergencia, registrar en la tabla de alertas SOS
            if alert_triggered:
                sql_alert = """
                    INSERT INTO alertas_sos (user_id, reason, contact_phone, status)
                    VALUES (%s, %s, %s, 'PENDIENTE')
                """
                cursor.execute(sql_alert, (user_str_id, alert_message, emergency_phone))

            conn.commit()

        return {
            "alert_triggered": alert_triggered,
            "message": alert_message,
            "emergency_contact": emergency_phone
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error procesando telemetría: {str(e)}")
    finally:
        conn.close()